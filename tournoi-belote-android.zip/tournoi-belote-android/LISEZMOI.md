# Tournoi Belote – application Android de test

Application Android qui embarque l'outil de tournoi (version hors ligne).
Les données sont enregistrées sur le téléphone : un seul appareil, tous les droits (administrateur).

## Obtenir l'APK sans rien installer (GitHub)
1. Créez un dépôt GitHub (privé si vous voulez) et envoyez-y le contenu de ce dossier.
2. GitHub compile automatiquement l'application (onglet **Actions**, ~5 minutes).
3. Ouvrez la compilation terminée et téléchargez **tournoi-belote-apk** (un .zip contenant `app-debug.apk`).

## Ou avec Android Studio
1. Fichier > Ouvrir > ce dossier.
2. Build > Build App Bundle(s) / APK(s) > Build APK(s).
3. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.

## Installer sur le téléphone
Copiez `app-debug.apk` sur le téléphone, ouvrez-le et autorisez « Installer des applications inconnues ».
Android peut afficher un avertissement de sécurité : c'est normal pour une application de test hors Play Store.

## Mettre à jour l'outil
Remplacez `app/src/main/assets/index.html` par la nouvelle version, puis recompilez.
