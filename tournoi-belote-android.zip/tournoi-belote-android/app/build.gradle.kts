plugins {
    id("com.android.application")
}

android {
    namespace = "com.tournoi.belote"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tournoi.belote"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-test"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
